public class RoxoCardFactory implements CardFactory {
    @Override
    public Card createCard() {
        return new RoxoCard();
    }
}
