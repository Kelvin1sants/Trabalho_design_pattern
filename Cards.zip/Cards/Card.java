public interface Card {
    String getColor();
    void display();
}
