public class RoxoCard implements Card {
    @Override
    public String getColor() {
        return "Roxo";
    }

    @Override
    public void display() {
        System.out.println("Abrindo pacote roxo de cards raros...");
    }
}
