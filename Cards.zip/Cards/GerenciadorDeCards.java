public class GerenciadorDeCards {
    private CardFactory cardFactory;

    public GerenciadorDeCards(CardFactory cardFactory) {
        this.cardFactory = cardFactory;
    }

    public void gerarCard() {
        Card card = cardFactory.createCard();
        card.display();
    }

    public static void main(String[] args) {
        // Gerando um card roxo
        GerenciadorDeCards gerenciadorRoxo = new GerenciadorDeCards(new RoxoCardFactory());
        gerenciadorRoxo.gerarCard();

        // Gerando um card azul
        GerenciadorDeCards gerenciadorAzul = new GerenciadorDeCards(new AzulCardFactory());
        gerenciadorAzul.gerarCard();
    }
}
