public class AzulCard implements Card {
    @Override
    public String getColor() {
        return "Azul";
    }

    @Override
    public void display() {
        System.out.println("Abrindo pacote azul de cards raros...");
    }
}
