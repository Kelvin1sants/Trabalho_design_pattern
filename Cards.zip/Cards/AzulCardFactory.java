public class AzulCardFactory implements CardFactory {
    @Override
    public Card createCard() {
        return new AzulCard();
    }
}
