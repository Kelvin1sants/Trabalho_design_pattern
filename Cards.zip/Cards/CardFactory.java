public interface CardFactory {
    Card createCard();
}
