public class Main {
    public static void main(String[] args) {
        // Usando BlueEyesWhiteDragon com Adapter
        BlueEyesWhiteDragon blueEyes = new BlueEyesWhiteDragon();
        Dragon blueEyesAdapter = new BlueEyesWhiteDragonAdapter(blueEyes);

        System.out.println("Carta: " + blueEyesAdapter.getName());
        System.out.println("Força: " + blueEyesAdapter.getPower());
        blueEyesAdapter.roar();

        // Usando RedEyesBlackDragon com Adapter
        RedEyesBlackDragon redEyes = new RedEyesBlackDragon();
        Dragon redEyesAdapter = new RedEyesBlackDragonAdapter(redEyes);

        System.out.println("Carta: " + redEyesAdapter.getName());
        System.out.println("Força: " + redEyesAdapter.getPower());
        redEyesAdapter.roar();
    }
}
