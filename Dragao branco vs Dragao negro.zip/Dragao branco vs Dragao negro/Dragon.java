public interface Dragon {
    String getName();
    int getPower();
    void roar();
}
