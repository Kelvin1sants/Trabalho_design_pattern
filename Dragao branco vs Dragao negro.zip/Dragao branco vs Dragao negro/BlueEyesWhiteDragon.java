public class BlueEyesWhiteDragon {
    public String name() {
        return "Blue Eyes White Dragon";
    }

    public int power() {
        return 3000;
    }

    public void makeSound() {
        System.out.println("Blue Eyes White Dragon é uma carta rara");
    }
}
