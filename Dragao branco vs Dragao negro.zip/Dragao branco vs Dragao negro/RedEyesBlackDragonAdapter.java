public class RedEyesBlackDragonAdapter implements Dragon {
    private RedEyesBlackDragon redEyesBlackDragon;

    public RedEyesBlackDragonAdapter(RedEyesBlackDragon redEyesBlackDragon) {
        this.redEyesBlackDragon = redEyesBlackDragon;
    }

    @Override
    public String getName() {
        return redEyesBlackDragon.name();
    }

    @Override
    public int getPower() {
        return redEyesBlackDragon.power();
    }

    @Override
    public void roar() {
        redEyesBlackDragon.makeSound();
    }
}
