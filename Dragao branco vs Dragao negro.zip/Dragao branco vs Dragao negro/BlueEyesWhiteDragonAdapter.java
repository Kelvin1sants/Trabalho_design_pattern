public class BlueEyesWhiteDragonAdapter implements Dragon {
    private BlueEyesWhiteDragon blueEyesWhiteDragon;

    public BlueEyesWhiteDragonAdapter(BlueEyesWhiteDragon blueEyesWhiteDragon) {
        this.blueEyesWhiteDragon = blueEyesWhiteDragon;
    }

    @Override
    public String getName() {
        return blueEyesWhiteDragon.name();
    }

    @Override
    public int getPower() {
        return blueEyesWhiteDragon.power();
    }

    @Override
    public void roar() {
        blueEyesWhiteDragon.makeSound();
    }
}
