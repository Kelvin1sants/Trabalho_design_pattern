public class RedEyesBlackDragon {
    public String name() {
        return "Red Eyes Black Dragon";
    }

    public int power() {
        return 6400;
    }

    public void makeSound() {
        System.out.println("Red Eyes Black Dragon é uma carta lendária");
    }
}
